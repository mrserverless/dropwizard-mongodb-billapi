
package com.apmasphere.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("com.googlecode.jsonschema2pojo")
@JsonPropertyOrder({
    "billID",
    "billStatus",
    "billPresentmentChargeAmount",
    "billProviderAPIGeneratedID",
    "billResourceCreatedDateTime",
    "billProviderABN",
    "billAccountNumberForInqueries",
    "billAccountNumberForPayment",
    "billDescription",
    "billServiceDateRangeStart",
    "billServiceDateRangeEnd",
    "billMetering",
    "billIssueDate",
    "billDueDate",
    "billTotalGST",
    "billTotalAmount",
    "billDiscountDate",
    "billDiscountAmount",
    "billInstallments",
    "billBpayCode",
    "billBpayRef",
    "billPostPayCode",
    "billPostPayRef",
    "billImageAvailableDateTime",
    "billImage"
})
public class Bill {

    @JsonProperty("billID")
    private String billID;
    @JsonProperty("billStatus")
    private String billStatus;
    @JsonProperty("billPresentmentChargeAmount")
    private Double billPresentmentChargeAmount;
    @JsonProperty("billProviderAPIGeneratedID")
    private String billProviderAPIGeneratedID;
    @JsonProperty("billResourceCreatedDateTime")
    private String billResourceCreatedDateTime;
    @JsonProperty("billProviderABN")
    private String billProviderABN;
    @JsonProperty("billAccountNumberForInqueries")
    private Integer billAccountNumberForInqueries;
    @JsonProperty("billAccountNumberForPayment")
    private Integer billAccountNumberForPayment;
    @JsonProperty("billDescription")
    private String billDescription;
    @JsonProperty("billServiceDateRangeStart")
    private String billServiceDateRangeStart;
    @JsonProperty("billServiceDateRangeEnd")
    private String billServiceDateRangeEnd;
    @JsonProperty("billMetering")
    private List<BillMetering> billMetering = new ArrayList<BillMetering>();
    @JsonProperty("billIssueDate")
    private String billIssueDate;
    @JsonProperty("billDueDate")
    private String billDueDate;
    @JsonProperty("billTotalGST")
    private Integer billTotalGST;
    @JsonProperty("billTotalAmount")
    private Double billTotalAmount;
    @JsonProperty("billDiscountDate")
    private String billDiscountDate;
    @JsonProperty("billDiscountAmount")
    private Integer billDiscountAmount;
    @JsonProperty("billInstallments")
    private List<BillInstallmants> billInstallments = new ArrayList<BillInstallmants>();
    @JsonProperty("billBpayCode")
    private Integer billBpayCode;
    @JsonProperty("billBpayRef")
    private Integer billBpayRef;
    @JsonProperty("billPostPayCode")
    private Integer billPostPayCode;
    @JsonProperty("billPostPayRef")
    private Integer billPostPayRef;
    @JsonProperty("billImageAvailableDateTime")
    private String billImageAvailableDateTime;
    @JsonProperty("billImage")
    private List<BillImage> billImage = new ArrayList<BillImage>();
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("billID")
    public String getBillID() {
        return billID;
    }

    @JsonProperty("billID")
    public void setBillID(String billID) {
        this.billID = billID;
    }

    @JsonProperty("billStatus")
    public String getBillStatus() {
        return billStatus;
    }

    @JsonProperty("billStatus")
    public void setBillStatus(String billStatus) {
        this.billStatus = billStatus;
    }

    @JsonProperty("billPresentmentChargeAmount")
    public Double getBillPresentmentChargeAmount() {
        return billPresentmentChargeAmount;
    }

    @JsonProperty("billPresentmentChargeAmount")
    public void setBillPresentmentChargeAmount(Double billPresentmentChargeAmount) {
        this.billPresentmentChargeAmount = billPresentmentChargeAmount;
    }

    @JsonProperty("billProviderAPIGeneratedID")
    public String getBillProviderAPIGeneratedID() {
        return billProviderAPIGeneratedID;
    }

    @JsonProperty("billProviderAPIGeneratedID")
    public void setBillProviderAPIGeneratedID(String billProviderAPIGeneratedID) {
        this.billProviderAPIGeneratedID = billProviderAPIGeneratedID;
    }

    @JsonProperty("billResourceCreatedDateTime")
    public String getBillResourceCreatedDateTime() {
        return billResourceCreatedDateTime;
    }

    @JsonProperty("billResourceCreatedDateTime")
    public void setBillResourceCreatedDateTime(String billResourceCreatedDateTime) {
        this.billResourceCreatedDateTime = billResourceCreatedDateTime;
    }

    @JsonProperty("billProviderABN")
    public String getBillProviderABN() {
        return billProviderABN;
    }

    @JsonProperty("billProviderABN")
    public void setBillProviderABN(String billProviderABN) {
        this.billProviderABN = billProviderABN;
    }

    @JsonProperty("billAccountNumberForInqueries")
    public Integer getBillAccountNumberForInqueries() {
        return billAccountNumberForInqueries;
    }

    @JsonProperty("billAccountNumberForInqueries")
    public void setBillAccountNumberForInqueries(Integer billAccountNumberForInqueries) {
        this.billAccountNumberForInqueries = billAccountNumberForInqueries;
    }

    @JsonProperty("billAccountNumberForPayment")
    public Integer getBillAccountNumberForPayment() {
        return billAccountNumberForPayment;
    }

    @JsonProperty("billAccountNumberForPayment")
    public void setBillAccountNumberForPayment(Integer billAccountNumberForPayment) {
        this.billAccountNumberForPayment = billAccountNumberForPayment;
    }

    @JsonProperty("billDescription")
    public String getBillDescription() {
        return billDescription;
    }

    @JsonProperty("billDescription")
    public void setBillDescription(String billDescription) {
        this.billDescription = billDescription;
    }

    @JsonProperty("billServiceDateRangeStart")
    public String getBillServiceDateRangeStart() {
        return billServiceDateRangeStart;
    }

    @JsonProperty("billServiceDateRangeStart")
    public void setBillServiceDateRangeStart(String billServiceDateRangeStart) {
        this.billServiceDateRangeStart = billServiceDateRangeStart;
    }

    @JsonProperty("billServiceDateRangeEnd")
    public String getBillServiceDateRangeEnd() {
        return billServiceDateRangeEnd;
    }

    @JsonProperty("billServiceDateRangeEnd")
    public void setBillServiceDateRangeEnd(String billServiceDateRangeEnd) {
        this.billServiceDateRangeEnd = billServiceDateRangeEnd;
    }

    @JsonProperty("billMetering")
    public List<BillMetering> getBillMetering() {
        return billMetering;
    }

    @JsonProperty("billMetering")
    public void setBillMetering(List<BillMetering> billMetering) {
        this.billMetering = billMetering;
    }

    @JsonProperty("billIssueDate")
    public String getBillIssueDate() {
        return billIssueDate;
    }

    @JsonProperty("billIssueDate")
    public void setBillIssueDate(String billIssueDate) {
        this.billIssueDate = billIssueDate;
    }

    @JsonProperty("billDueDate")
    public String getBillDueDate() {
        return billDueDate;
    }

    @JsonProperty("billDueDate")
    public void setBillDueDate(String billDueDate) {
        this.billDueDate = billDueDate;
    }

    @JsonProperty("billTotalGST")
    public Integer getBillTotalGST() {
        return billTotalGST;
    }

    @JsonProperty("billTotalGST")
    public void setBillTotalGST(Integer billTotalGST) {
        this.billTotalGST = billTotalGST;
    }

    @JsonProperty("billTotalAmount")
    public Double getBillTotalAmount() {
        return billTotalAmount;
    }

    @JsonProperty("billTotalAmount")
    public void setBillTotalAmount(Double billTotalAmount) {
        this.billTotalAmount = billTotalAmount;
    }

    @JsonProperty("billDiscountDate")
    public String getBillDiscountDate() {
        return billDiscountDate;
    }

    @JsonProperty("billDiscountDate")
    public void setBillDiscountDate(String billDiscountDate) {
        this.billDiscountDate = billDiscountDate;
    }

    @JsonProperty("billDiscountAmount")
    public Integer getBillDiscountAmount() {
        return billDiscountAmount;
    }

    @JsonProperty("billDiscountAmount")
    public void setBillDiscountAmount(Integer billDiscountAmount) {
        this.billDiscountAmount = billDiscountAmount;
    }

    @JsonProperty("billInstallments")
    public List<BillInstallmants> getBillInstallments() {
        return billInstallments;
    }

    @JsonProperty("billInstallments")
    public void setBillInstallments(List<BillInstallmants> billInstallments) {
        this.billInstallments = billInstallments;
    }

    @JsonProperty("billBpayCode")
    public Integer getBillBpayCode() {
        return billBpayCode;
    }

    @JsonProperty("billBpayCode")
    public void setBillBpayCode(Integer billBpayCode) {
        this.billBpayCode = billBpayCode;
    }

    @JsonProperty("billBpayRef")
    public Integer getBillBpayRef() {
        return billBpayRef;
    }

    @JsonProperty("billBpayRef")
    public void setBillBpayRef(Integer billBpayRef) {
        this.billBpayRef = billBpayRef;
    }

    @JsonProperty("billPostPayCode")
    public Integer getBillPostPayCode() {
        return billPostPayCode;
    }

    @JsonProperty("billPostPayCode")
    public void setBillPostPayCode(Integer billPostPayCode) {
        this.billPostPayCode = billPostPayCode;
    }

    @JsonProperty("billPostPayRef")
    public Integer getBillPostPayRef() {
        return billPostPayRef;
    }

    @JsonProperty("billPostPayRef")
    public void setBillPostPayRef(Integer billPostPayRef) {
        this.billPostPayRef = billPostPayRef;
    }

    @JsonProperty("billImageAvailableDateTime")
    public String getBillImageAvailableDateTime() {
        return billImageAvailableDateTime;
    }

    @JsonProperty("billImageAvailableDateTime")
    public void setBillImageAvailableDateTime(String billImageAvailableDateTime) {
        this.billImageAvailableDateTime = billImageAvailableDateTime;
    }

    @JsonProperty("billImage")
    public List<BillImage> getBillImage() {
        return billImage;
    }

    @JsonProperty("billImage")
    public void setBillImage(List<BillImage> billImage) {
        this.billImage = billImage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperties(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
